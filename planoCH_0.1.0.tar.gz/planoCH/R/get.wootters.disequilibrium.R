get.wootters.disequilibrium <- function(counts, counts.ref, counts.max_to_ref, ...)
{
  D <- get.wootters.distance(counts, counts.ref, ...)
  Dmax <- get.wootters.distance(counts.max_to_ref, counts.ref, ...)
  Q0 <- 1 / Dmax
  Q <- Q0 * D

  data.frame(D, Q0, Q)
}
